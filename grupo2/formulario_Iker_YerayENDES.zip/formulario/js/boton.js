function calcularResultado() {
      const respuestas = document.querySelectorAll('input[type=radio]:checked');
      let puntos = 0;
      respuestas.forEach(r => {
        if (r.value === "correcta") puntos++;
      });
      const total = 8; // número de preguntas
      const resultado = document.getElementById("resultado");

      resultado.textContent = `✅ Has acertado ${puntos} de ${total} preguntas.`;
      if (puntos === total) {
        resultado.style.color = "green";
      } else if (puntos >= total / 2) {
        resultado.style.color = "orange";
      } else {
        resultado.style.color = "red";
      }
    }